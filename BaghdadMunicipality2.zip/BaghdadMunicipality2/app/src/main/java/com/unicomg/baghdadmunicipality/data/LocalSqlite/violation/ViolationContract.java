package com.unicomg.baghdadmunicipality.data.LocalSqlite.violation;

import android.provider.BaseColumns;

public class ViolationContract {
    public static final class ItemEntry implements BaseColumns {
        public static final String VIOLATION_TABLE_TABLE = "violation" ;
        public static final String VIOLATIONs_ID = "_id";
        public static final String SHOP_ID = "shop_id";
        public static final String CATEGORY_ID = "category_id";
        public static final String VIOLATION_ID = "violation_id";
        public static final String ACTION_ID = "action_id";
        public static final String NOTE = "note";
    }
}
