package com.unicomg.baghdadmunicipality.Views.shopslist;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.unicomg.baghdadmunicipality.R;
import com.unicomg.baghdadmunicipality.Views.add_bill_board.AddBillFragment;
import com.unicomg.baghdadmunicipality.Views.add_shops.AddShopFragment;
import com.unicomg.baghdadmunicipality.data.models.shops.ShopModel;
import com.unicomg.baghdadmunicipality.data.models.shops.ShopModel2;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;
import com.unicomg.baghdadmunicipality.helper.ConnectivityReceiver;

import java.util.ArrayList;

import javax.inject.Inject;


public class ShopsListFragment extends Fragment implements ShopListView, ConnectivityReceiver.ConnectivityReceiverListener, ShopItemClick {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private OnFragmentInteractionListener mListener;

    @Inject
    ShopsListPresenter mainPresenter;

    RecyclerView recyclerView;
    ProgressBar loading_indicator;
    ShopsAdapter shopsAdapter;

    public ShopsListFragment() {
        // Required empty public constructor
    }


    public static ShopsListFragment newInstance(String param1, String param2) {
        ShopsListFragment fragment = new ShopsListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        //register some activity   for injections
        ((DaggerApplication) getActivity().getApplication()).getAppComponent().inject(this);
        mainPresenter.onAttach(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_shops_list, container, false);

        Button add_bill_intent_btn = view.findViewById(R.id.add_shop_intent_btn);
        add_bill_intent_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddShopFragment fragment = AddShopFragment.newInstance("", "");
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction =
                        fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameLayout_container, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        recyclerView = view.findViewById(R.id.main_shops);
        loading_indicator = view.findViewById(R.id.loading_indicator);
        GridLayoutManager layoutManager
                = new GridLayoutManager(getContext(), 2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        shopsAdapter = new ShopsAdapter(this);

        mainPresenter.getShops();
        return view;

    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onAttache() {

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void sendOneShop(ShopModel2  shopModel2 ,  View v, int position) {

        mainPresenter.sendOnShopData(new ShopModel(shopModel2.getOwner_name() , shopModel2.getType() , shopModel2.getShop_activity_id() , shopModel2.getWidth() , shopModel2.getLength()
                , shopModel2.getEmployee_number() , shopModel2.getFloor_number() , shopModel2.getArea() , shopModel2.getStreet() ,shopModel2.getAlley() ,shopModel2.getLocality() ,
                shopModel2.getLocality_number(), shopModel2.getLicense_number() ,
                shopModel2.getLicense_type() , shopModel2.getLicense_date() , shopModel2.getLicense_end_date() , shopModel2.getBillboard_name() ,shopModel2.getBillboard_type() ,
                shopModel2.getBillboard_width() , shopModel2.getBillboard_length() ,shopModel2.getBillboard_height() ,shopModel2.getBillboard_font_type()) , shopModel2.getId());
    }

    @Override
    public void updateJob(View v, int position) {

    }

    @Override
    public void showMessage(String message, int mColor) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showLoading() {
        loading_indicator.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loading_indicator.setVisibility(View.GONE);
    }

    @Override
    public void showShops(ArrayList<ShopModel2> shopModels) {
        if (shopModels.isEmpty()) {
            hideLoading();
        } else {
            shopsAdapter.setShopsData(shopModels, getContext());
            recyclerView.setAdapter(shopsAdapter);
        }
    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {

    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
