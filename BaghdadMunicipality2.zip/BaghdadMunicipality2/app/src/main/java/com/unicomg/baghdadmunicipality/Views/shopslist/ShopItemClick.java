package com.unicomg.baghdadmunicipality.Views.shopslist;

import android.view.View;

import com.unicomg.baghdadmunicipality.data.models.shops.ShopModel2;

public interface ShopItemClick {

    void sendOneShop(ShopModel2 shopModel2 , View v, int position);
    void updateJob(View v, int position);
}
