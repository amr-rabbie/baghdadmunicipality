package com.unicomg.baghdadmunicipality.Views.mainscreen;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;

import com.unicomg.baghdadmunicipality.R;
import com.unicomg.baghdadmunicipality.Views.add_bill_board.AddBillFragment;
import com.unicomg.baghdadmunicipality.Views.add_shops.AddShopFragment;
import com.unicomg.baghdadmunicipality.Views.add_violation.AddViolationFragment;
import com.unicomg.baghdadmunicipality.Views.add_bill_board.AddBillFragment;
import com.unicomg.baghdadmunicipality.Views.add_violation.AddViolationFragment;
import com.unicomg.baghdadmunicipality.Views.bill_board_list.BillListFragment;
import com.unicomg.baghdadmunicipality.Views.shopslist.ShopsListFragment;
import com.unicomg.baghdadmunicipality.Views.violations_list.ViolationsListFragment;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements ShopsListFragment.OnFragmentInteractionListener , BillListFragment.OnFragmentInteractionListener ,
        ViolationsListFragment.OnFragmentInteractionListener, AddBillFragment.OnFragmentInteractionListener, AddViolationFragment.OnFragmentInteractionListener {

    @BindView(R.id.shops_btn)
    LinearLayout shops_btn;
    @BindView(R.id.bills_btn)
    LinearLayout bills_btn;
    @BindView(R.id.violation_btn)
    LinearLayout violation_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        shops_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShopsListFragment fragment = ShopsListFragment.newInstance("", "");
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction =
                        fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameLayout_container, fragment);
                //fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

        bills_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BillListFragment fragment = BillListFragment.newInstance("", "");
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction =
                        fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameLayout_container, fragment);
                //fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        violation_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViolationsListFragment fragment = ViolationsListFragment.newInstance("", "");
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction =
                        fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameLayout_container, fragment);
                //fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
