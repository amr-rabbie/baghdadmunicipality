package com.unicomg.baghdadmunicipality.Views.add_bill_board;

import android.content.Context;
import android.util.Log;

import com.unicomg.baghdadmunicipality.baseClass.BasePresenter;
import com.unicomg.baghdadmunicipality.data.ApisClient.ApiInterface;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.ItemDbHelper;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardModel;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardResponse;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;
import com.unicomg.baghdadmunicipality.helper.Constants;
import com.unicomg.baghdadmunicipality.helper.Utilities;

import javax.inject.Inject;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class AddBillPresenter implements BasePresenter<AddBillView> {


    AddBillView mView;
    boolean isLoaded = false;
    @Inject
    ApiInterface mApiInterface;
    @Inject
    Context mContext;
    @Inject
    ItemDbHelper mItemDbHelper;
    @Override
    public void onAttach(AddBillView view) {
        mView = view;
        mView.onAttache();
    }

    @Override
    public void onDetach() {
        mView = null;
    }

    //create Constructor to get reference of api interface object
    public AddBillPresenter(Context context){
        ((DaggerApplication)context).getAppComponent().inject(this);
    }

    public void saveLocally(BillboardModel billboardModel) {
        mItemDbHelper.addBillBoard(billboardModel);
    }

    public void saveToServer(final BillboardModel billboardModel) {
        if (!Utilities.checkConnection(mContext)) {
            mView.showMessage("من فضلك قم بالاتصال بالانترنت");
            mView.hideLoading();
            return;
        }

        mView.showLoading();
        mApiInterface.saveBillboard("Bearer " + Constants.getuserToken(mContext), billboardModel)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<BillboardResponse>() {
                    @Override
                    public final void onCompleted() {

                    }

                    @Override
                    public final void onError(Throwable e) {
                        mView.showMessage("تم حفظ البيانات محليا ");
                        mView.hideLoading();
                        Log.e("Sr_info_ big onError:",  e.getMessage() );
                        saveLocally(billboardModel);
                    }

                    @Override
                    public final void onNext(BillboardResponse response) {

                        if (response.getStatus().equals("success")) {
                            Log.e("Sr_info_ big onNext:", "message : " + response.getMessage() + "status : "  + response.getStatus());
                        } else {
                            Log.e("Sr_info_ big onNext:", "message : " + response.getMessage() + "status : "  + response.getStatus());
                            mView.hideLoading();
                            mView.showMessage(response.getMessage());
                        }
                        if (response.getStatus().equals("success")) {
                            Log.e("Sr_info_ big onNext:", "message : " + response.getMessage() + "status : "  + response.getStatus());
                            mView.showMessage("تم حفظ البيانات علي السيرفير ");
                            mView.hideLoading();
                        } else {
                            Log.e("Sr_info_ big onNext:", "message : " + response.getMessage() + "status : "  + response.getStatus());
                            mView.hideLoading();
                            mView.showMessage(response.getMessage());
                        }

                    }
                });

    }
}
