package com.unicomg.baghdadmunicipality.data.models.allviolations;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ViolationsResponse {

    @SerializedName("status")
    String status ;
    @SerializedName("message")
    String message ;
    @SerializedName("data")
    List<Violation> violations ;

    public ViolationsResponse(String status, String message, List<Violation> violations) {
        this.status = status;
        this.message = message;
        this.violations = violations;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Violation> getViolations() {
        return violations;
    }

    public void setViolations(List<Violation> violations) {
        this.violations = violations;
    }

    @Override
    public String toString() {
        return "ViolationsResponse{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", violations=" + violations +
                '}';
    }
}
