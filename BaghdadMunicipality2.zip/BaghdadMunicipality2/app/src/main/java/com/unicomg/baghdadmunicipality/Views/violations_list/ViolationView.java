package com.unicomg.baghdadmunicipality.Views.violations_list;

import com.unicomg.baghdadmunicipality.baseClass.BaseView;

public interface ViolationView   extends BaseView {

    void showMessage(String message, int mColor);

}
