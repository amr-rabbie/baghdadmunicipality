package com.unicomg.baghdadmunicipality.data.ApisClient;


public class EndPoints {
 public static final String BASE_URL = "http://192.168.3.236:88/baldiat/api/";
 public static final String LOGIN = "login";
 public static final String GET_LOGin_Data = "user";
 public static final String GET_Shops_ctivities = "all-shop-activities";
 public static final String Post_Add_Shop_Data = "add-shop-data";
 public static final String GET_USER = "user";
 public static final String ALL_SHOP_ACTIVITIES = "all-shop-activities";
 public static final String ALL_CATEGORIES = "all-categories";
 public static final String ALL_VIOLATIONS = "all-violations/{categoryId}";
 public static final String ADD_SHOP_DATA = "add-shop-data";
 public static final String ADD_BILLBORAD = "add-billboard";
 public static final String ADD_VILATION_MONITORING = "add-violations-monitoring";
 public static final String ADD_IMAGE = "add-image";

}
