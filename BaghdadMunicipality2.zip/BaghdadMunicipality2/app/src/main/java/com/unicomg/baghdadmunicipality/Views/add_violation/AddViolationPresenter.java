package com.unicomg.baghdadmunicipality.Views.add_violation;

import android.content.Context;

import com.unicomg.baghdadmunicipality.Views.violations_list.ViolationView;
import com.unicomg.baghdadmunicipality.baseClass.BasePresenter;
import com.unicomg.baghdadmunicipality.data.ApisClient.ApiInterface;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.ItemDbHelper;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;

import javax.inject.Inject;

public class AddViolationPresenter  implements BasePresenter<AddViolationView> {

    AddViolationView mView;
    boolean isLoaded = false;
    @Inject
    ApiInterface mApiInterface;
    @Inject
    Context mContext;
    @Inject
    ItemDbHelper mItemDbHelper;
    @Override
    public void onAttach(AddViolationView view) {
        mView = view;
        mView.onAttache();
    }

    @Override
    public void onDetach() {
        mView = null;
    }

    //create Constructor to get reference of api interface object
    public AddViolationPresenter(Context context){
        ((DaggerApplication)context).getAppComponent().inject(this);
    }

    void checkConnection(boolean isConnected) {
        //check internet and  data not loaded
        if(isConnected  && !isLoaded){

            isLoaded = false;
            //   mView.showMessage(mContext.getString(R.string.connect_to_internet),Color.GREEN);
        }

        if(!isConnected){
            new android.os.Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    //
                    //mView.startLoginActivity();
                }
            } , 1000);

        }
        else if(!isConnected && isLoaded){
            //offline check and  data loaded
            //  mView.showMessage(mContext.getString(R.string.offline),Color.WHITE);

        }
        else if(!isConnected && !isLoaded){
            //get offline  data using realm
            //mView.showMessage(mContext.getString(R.string.get_data_from_local),Color.WHITE);
            //     mView.updateList(mItemDbHelper.getAllItems());

        }else if(isConnected && isLoaded){
            //mView.showMessage(mContext.getString(R.string.connect_to_internet),Color.GREEN);
        }
    }

}
