package com.unicomg.baghdadmunicipality.Views.bill_board_list;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.unicomg.baghdadmunicipality.R;
import com.unicomg.baghdadmunicipality.Views.add_bill_board.AddBillFragment;
import com.unicomg.baghdadmunicipality.Views.add_bill_board.AddBillFragment;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardModel;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardModel2;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;
import com.unicomg.baghdadmunicipality.helper.ConnectivityReceiver;
import java.util.ArrayList;
import javax.inject.Inject;


public class BillListFragment extends Fragment implements BillListView, ConnectivityReceiver.ConnectivityReceiverListener, BillboardItemClick {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private OnFragmentInteractionListener mListener;
    @Inject
    BillListPresenter mainPresenter;
    RecyclerView recyclerView;
    ProgressBar loading_indicator;
    BillboardAdapter billboardAdapter;
    public BillListFragment() {

    }

    public static BillListFragment newInstance(String param1, String param2) {
        BillListFragment fragment = new BillListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        //register some activity   for injections
        ((DaggerApplication) getActivity().getApplication()).getAppComponent().inject(this);
        mainPresenter.onAttach(this);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bill_list, container, false);

        Button add_bill_intent_btn = view.findViewById(R.id.add_bill_intent_btn);
        add_bill_intent_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddBillFragment fragment = AddBillFragment.newInstance("", "");
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction =
                        fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameLayout_container, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        recyclerView = view.findViewById(R.id.main_bill_boards);
        loading_indicator = view.findViewById(R.id.loading_indicator);
        GridLayoutManager layoutManager
                = new GridLayoutManager(getContext(), 2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        billboardAdapter = new BillboardAdapter(this);

        mainPresenter.getBillBoards();
        return view;



    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onAttache() {

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void showMessage(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showLoading() {
        loading_indicator.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loading_indicator.setVisibility(View.GONE);
    }

    @Override
    public void showBillBoards(ArrayList<BillboardModel2> billboardModels) {
//        if (billboardModels.isEmpty()) {
//
//        } else {
//            billboardAdapter.setBillBoardData(billboardModels, getContext());
//            recyclerView.setAdapter(billboardAdapter);
//        }

        hideLoading();
        billboardAdapter.setBillBoardData(billboardModels, getContext());
        recyclerView.setAdapter(billboardAdapter);
    }


    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {

    }

    @Override
    public void sendBillboard(BillboardModel2 billboardModel , View v, int position) {

        BillboardModel sendedBillboard = new BillboardModel(billboardModel.getOwner_name() , billboardModel.getBillboard_name() ,
                billboardModel.getBillboard_type() , billboardModel.getWidth() , billboardModel.getLength() , billboardModel.getHeight() ,
                billboardModel.getFont_language() ,billboardModel.getArea() , billboardModel.getArea() , billboardModel.getAilley() , billboardModel.getStreet() ,
                billboardModel.getBulding_number() , billboardModel.getBillboard_license() ,billboardModel.getBillboard_license_number() ,
                billboardModel.getLicense_date() , billboardModel.getLicense_end_date()) ;

        mainPresenter.sendOneBillboard(sendedBillboard , billboardModel.getId());
    }

    @Override
    public void updateJob(View v, int position) {

    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
