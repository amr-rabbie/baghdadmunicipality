package com.unicomg.baghdadmunicipality.data.LocalSqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import com.unicomg.baghdadmunicipality.data.LocalSqlite.allviolences.AllViolenceContract;
import com.google.gson.annotations.SerializedName;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.billBoard.BillBoardContract;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.categories.CategoriesContract;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.shops.ShopsContract;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.shopsactivities.ShopsActivitiesContract;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.violation.ViolationContract;
import com.unicomg.baghdadmunicipality.data.models.allviolations.Violation;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardModel;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardModel2;
import com.unicomg.baghdadmunicipality.data.models.category.Category;
import com.unicomg.baghdadmunicipality.data.models.shops.ShopModel;
import com.unicomg.baghdadmunicipality.data.models.shops.ShopModel2;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesDetailsResponse;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesResponse;
import com.unicomg.baghdadmunicipality.data.models.violation.ViolationModel;

import java.util.ArrayList;
import java.util.List;

import static com.unicomg.baghdadmunicipality.data.LocalSqlite.allviolences.AllViolenceContract.ItemEntry.All_Violences_TABLE_NAME;
//import static com.unicomg.baghdadmunicipality.data.LocalSqlite.billBoard.BillBoardContract.ItemEntry.BILL_BOARD_Id;
import static com.unicomg.baghdadmunicipality.data.LocalSqlite.billBoard.BillBoardContract.ItemEntry.BILL_BOARD_TABLE_NAME;
import static com.unicomg.baghdadmunicipality.data.LocalSqlite.categories.CategoriesContract.ItemEntry.Categories_TABLE_NAME;
import static com.unicomg.baghdadmunicipality.data.LocalSqlite.shops.ShopsContract.ItemEntry.Shop_TABLE_NAME;
import static com.unicomg.baghdadmunicipality.data.LocalSqlite.shops.ShopsContract.ItemEntry.owner_name;
import static com.unicomg.baghdadmunicipality.data.LocalSqlite.shops.ShopsContract.ItemEntry.shop_id;
import static com.unicomg.baghdadmunicipality.data.LocalSqlite.shopsactivities.ShopsActivitiesContract.ItemEntry.Shop_Activities_TABLE_NAME;
import static com.unicomg.baghdadmunicipality.data.LocalSqlite.violation.ViolationContract.ItemEntry.VIOLATION_TABLE_TABLE;
import static com.unicomg.baghdadmunicipality.data.LocalSqlite.violation.ViolationContract.ItemEntry.VIOLATIONs_ID;


public class ItemDbHelper  extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "SurveyDB.db";
    private static final int VERSION = 1;
    public ItemDbHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        final String CREATE_BILL_BOARD_TABLE = "CREATE TABLE " + BILL_BOARD_TABLE_NAME + " (" +
                BillBoardContract.ItemEntry._ID + " INTEGER PRIMARY KEY, " +
                BillBoardContract.ItemEntry.OWNER_NAME + " TEXT , " +
                BillBoardContract.ItemEntry.BILLBOARD_NAME + " TEXT , " +
                BillBoardContract.ItemEntry.BILLBOARD_TYPE + " TEXT , " +
                BillBoardContract.ItemEntry.WIDTH + " TEXT , " +
                BillBoardContract.ItemEntry.HEIGHT + " TEXT , " +
                BillBoardContract.ItemEntry.LENGTH + " TEXT , " +
                BillBoardContract.ItemEntry.FONT_LANGUAGE + " TEXT , " +
                BillBoardContract.ItemEntry.AREA + " TEXT , " +
                BillBoardContract.ItemEntry.LOCALITY + " TEXT , " +
                BillBoardContract.ItemEntry.AILLEY + " TEXT , " +
                BillBoardContract.ItemEntry.STREET + " TEXT , " +
                BillBoardContract.ItemEntry.BULDING_NUMBER + " TEXT , " +
                BillBoardContract.ItemEntry.BILLBOARD_LICENSE + " TEXT , " +
                BillBoardContract.ItemEntry.BILLBOARD_LICENSE_NUMBER + " TEXT , " +
                BillBoardContract.ItemEntry.LICENSE_DATE + " TEXT , " +
                BillBoardContract.ItemEntry.LICENSE_END_DATE + " TEXT );";

        db.execSQL(CREATE_BILL_BOARD_TABLE);

       // =================================================

        //amr rabie create shopdata table

        final String CREATE_ShopData_TABLE = "CREATE TABLE " + Shop_TABLE_NAME + " (" +
                ShopsContract.ItemEntry._ID + " INTEGER PRIMARY KEY, " +
                ShopsContract.ItemEntry.owner_name + " TEXT , " +
                ShopsContract.ItemEntry.type + " TEXT , " +
                ShopsContract.ItemEntry.shop_activity_id + " TEXT , " +
                ShopsContract.ItemEntry.width + " TEXT , " +
                ShopsContract.ItemEntry.length + " TEXT , " +
                ShopsContract.ItemEntry.employee_number + " TEXT , " +

                ShopsContract.ItemEntry.floor_number + " TEXT , " +
                ShopsContract.ItemEntry.area + " TEXT , " +
                ShopsContract.ItemEntry.street + " TEXT , " +
                ShopsContract.ItemEntry.locality + " TEXT , " +
                ShopsContract.ItemEntry.alley + " TEXT , " +
                ShopsContract.ItemEntry.locality_number + " TEXT , " +

                ShopsContract.ItemEntry.license_number + " TEXT , " +
                ShopsContract.ItemEntry.license_date + " TEXT , " +
                ShopsContract.ItemEntry.license_end_date + " TEXT , " +
                ShopsContract.ItemEntry.license_type + " TEXT , " +
                ShopsContract.ItemEntry.billboard_name + " TEXT , " +
                ShopsContract.ItemEntry.billboard_type + " TEXT , " +

                ShopsContract.ItemEntry.billboard_width + " TEXT , " +
                ShopsContract.ItemEntry.billboard_length + " TEXT , " +
                ShopsContract.ItemEntry.billboard_height + " TEXT , " +

                ShopsContract.ItemEntry.billboard_font_type + " TEXT );";
        db.execSQL(CREATE_ShopData_TABLE);

        //////////

        final String CREATE_Shop_Activities_TABLE = "CREATE TABLE " + Shop_Activities_TABLE_NAME + " (" +
                ShopsActivitiesContract.ItemEntry._ID + " INTEGER PRIMARY KEY, " +
                ShopsActivitiesContract.ItemEntry.id + " TEXT , " +
                ShopsActivitiesContract.ItemEntry.name + " TEXT , " +
                ShopsActivitiesContract.ItemEntry.code + " TEXT );";
        db.execSQL(CREATE_Shop_Activities_TABLE);

        ///////////////////

        final String CREATE_Categories_TABLE = "CREATE TABLE " + Categories_TABLE_NAME + " (" +
                CategoriesContract.ItemEntry._ID + " INTEGER PRIMARY KEY, " +
                CategoriesContract.ItemEntry.id + " TEXT , " +
                CategoriesContract.ItemEntry.name + " TEXT , " +


                CategoriesContract.ItemEntry.code + " TEXT );";
        db.execSQL(CREATE_Categories_TABLE);

        /////////////


        final String CREATE_All_Viiolences_TABLE = "CREATE TABLE " + All_Violences_TABLE_NAME + " (" +
                AllViolenceContract.ItemEntry._ID + " INTEGER PRIMARY KEY, " +
                AllViolenceContract.ItemEntry.id + " TEXT , " +
                AllViolenceContract.ItemEntry.name + " TEXT , " +

                AllViolenceContract.ItemEntry.type + " TEXT , " +
                AllViolenceContract.ItemEntry.financial_value + " TEXT , " +

                AllViolenceContract.ItemEntry.category_id + " TEXT );";
        db.execSQL(CREATE_All_Viiolences_TABLE);







        ////////////////


        final String CREATE_Violation_TABLE = "CREATE TABLE " + VIOLATION_TABLE_TABLE + " (" +
                ViolationContract.ItemEntry._ID + " INTEGER PRIMARY KEY, " +
                ViolationContract.ItemEntry.SHOP_ID + " TEXT , " +
                ViolationContract.ItemEntry.CATEGORY_ID + " TEXT , " +
                ViolationContract.ItemEntry.VIOLATION_ID + " TEXT , " +
                ViolationContract.ItemEntry.ACTION_ID + " TEXT , " +


                ViolationContract.ItemEntry.NOTE + " TEXT );";
        db.execSQL(CREATE_Violation_TABLE);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//        db.execSQL("DROP TABLE IF EXISTS " + GOVERNOR_TABLE_NAME);
//        onCreate(db);
    }
/*
    public List<Governor>  getGovs() {

        String[] columns={GOV_ID , GOV_NAME};
        List<Governor>  governors = new ArrayList<>();
        // Get access to underlying database (read-only for query)
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor =  db.query(GOVERNOR_TABLE_NAME,
                columns,
                null,
                null,
                null,
                null,
                null);


        if(retCursor!=null){
            while (retCursor.moveToNext()) {
                Governor  governor = new Governor();
                // governor.setId(retCursor.getInt(retCursor.getColumnIndex(ItemContract.ItemEntry._ID)));
                governor.setGov_id( retCursor.getString(retCursor.getColumnIndex(GOV_ID)));
                governor.setGov_name( retCursor.getString(retCursor.getColumnIndex(GOV_NAME)));
                governors.add(governor);
            }
        }

        return  governors;
    }
    public void addPositions(List<PositionResponseDetails> positionResponseDetails) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(PositionsContract.ItemEntry.position_id, "0");
            values.put(PositionsContract.ItemEntry.project_id, "0");
            values.put(PositionsContract.ItemEntry.position_name, "اختر الوظيفة");
            db.insert(POSITION_TABLE_NAME, null, values);
            for (PositionResponseDetails positionResponseDetails1 : positionResponseDetails) {
                values.put(PositionsContract.ItemEntry.position_id, positionResponseDetails1.getPosition_id());
                values.put(PositionsContract.ItemEntry.project_id, positionResponseDetails1.getProject_id());
                values.put(PositionsContract.ItemEntry.position_name, positionResponseDetails1.getPosition_name());


                db.insert(POSITION_TABLE_NAME, null, values);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
    public void addPosition(PositionResponseDetails positionResponseDetails) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
                values.put(PositionsContract.ItemEntry.position_id, positionResponseDetails.getPosition_id());
                values.put(PositionsContract.ItemEntry.project_id, positionResponseDetails.getProject_id());
                values.put(PositionsContract.ItemEntry.position_name, positionResponseDetails.getPosition_name());
                db.insert(POSITION_TABLE_NAME, null, values);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
    public List<PositionResponseDetails>  getPositions() {
        List<PositionResponseDetails>  positionResponses = new ArrayList<>();
        // Get access to underlying database (read-only for query)
        final SQLiteDatabase db = this.getReadableDatabase();
        Cursor retCursor;
        retCursor =  db.query(POSITION_TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                null);
        if(retCursor!=null){
            while (retCursor.moveToNext()) {
                PositionResponseDetails  positionResponseDetails = new PositionResponseDetails();
                positionResponseDetails.setPosition_id( retCursor.getString(retCursor.getColumnIndex(PositionsContract.ItemEntry.position_id)));
                positionResponseDetails.setProject_id( retCursor.getString(retCursor.getColumnIndex(PositionsContract.ItemEntry.project_id)));
                positionResponseDetails.setPosition_name( retCursor.getString(retCursor.getColumnIndex(PositionsContract.ItemEntry.position_name)));
                positionResponses.add(positionResponseDetails);
            }
        }

        return  positionResponses;
    }
    public void addGovernors(ArrayList<Governor> governors) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(GOV_ID, 0);
            values.put(GOV_NAME, "اختر المحافظة");
            db.insert(GOVERNOR_TABLE_NAME, null, values);
            for (Governor governor : governors) {
                values.put(GOV_ID, governor.getGov_id());
                values.put(GOV_NAME, governor.getGov_name());
                db.insert(GOVERNOR_TABLE_NAME, null, values);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
    public ArrayList<Governor> getGovernors() {
        ArrayList<Governor> governors = new ArrayList<>();
        // Get access to underlying database (read-only for query)
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(GOVERNOR_TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                Governor governor = new Governor();
                governor.setGov_id(retCursor.getString(retCursor.getColumnIndex(GOV_ID)));
                governor.setGov_name(retCursor.getString(retCursor.getColumnIndex(GOV_NAME)));
                governors.add(governor);
            }
        }

        return governors;
    }
    public void deleteSavedGovernors() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from  " + GOVERNOR_TABLE_NAME);

    }
    public void deleteSavedPositionTable() {
          SQLiteDatabase db = this.getWritableDatabase();
          db.execSQL("delete from  " + POSITION_TABLE_NAME);
      }
    public ArrayList<Job> getJobs(String project_id , String office_id , String user_id) {
        ArrayList<Job> jobs = new ArrayList<>();
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(JOB_TABLE_NAME,
                null,
                PROJECT_ID + "=" + project_id + " and " + OFFICE_ID + "=" + office_id
                        + " and " + USER_ID + "=" + user_id,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                Job job = new Job();
                // governor.setId(retCursor.getInt(retCursor.getColumnIndex(ItemContract.ItemEntry._ID)));
                job.setJob_id(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.JOB_ID)));
                job.setJob_name(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.JOB_NAME)));
                job.setCount(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.COUNT)));
                job.setNote(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.NOTE)));
                job.setProject_id(retCursor.getString(retCursor.getColumnIndex(PROJECT_ID)));
                job.setUser_id(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.USER_ID)));
                job.setOffice_id(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.OFFICE_ID)));
                jobs.add(job);
            }
        }

        return jobs;
    }
    public ArrayList<Job> getJobsByUserId(String user_id , String officeId) {
        ArrayList<Job> jobs = new ArrayList<>();
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(JOB_TABLE_NAME,
                null,
                USER_ID + " = " + user_id + " and " +OFFICE_ID + " = " + officeId,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                Job job = new Job();
                // governor.setId(retCursor.getInt(retCursor.getColumnIndex(ItemContract.ItemEntry._ID)));
                job.setJob_id(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.JOB_ID)));
                job.setJob_name(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.JOB_NAME)));
                job.setCount(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.COUNT)));
                job.setNote(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.NOTE)));
                job.setProject_id(retCursor.getString(retCursor.getColumnIndex(PROJECT_ID)));
                job.setUser_id(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.USER_ID)));
                job.setOffice_id(retCursor.getString(retCursor.getColumnIndex(JobContract.ItemEntry.OFFICE_ID)));

                jobs.add(job);
            }
        }

        return jobs;
    }
    public boolean updateJob(String jobId , Job job) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues args = new ContentValues();

        args.put(JobContract.ItemEntry.JOB_ID, job.getJob_id());

        args.put(JobContract.ItemEntry.JOB_NAME, job.getJob_name());

        args.put(JobContract.ItemEntry.NOTE, job.getNote());

        args.put(JobContract.ItemEntry.COUNT, job.getCount());

        args.put(PROJECT_ID, job.getProject_id());

        args.put(JobContract.ItemEntry.USER_ID, job.getUser_id());

        args.put(JobContract.ItemEntry.OFFICE_ID, job.getOffice_id());

        return db.update(JOB_TABLE_NAME, args, JOB_ID + " = " + jobId + " and " +
                PROJECT_ID + " = " + job.getProject_id() + " and " + OFFICE_ID + " = " + job.getOffice_id()
                + " and " + USER_ID + " = " + job.getUser_id(), null) > 0;

    }
    public ArrayList<PositionResponseDetails> getCertainPosition(String projectId) throws SQLException {
        ArrayList<PositionResponseDetails> positions = new ArrayList<>();

        final SQLiteDatabase db = this.getReadableDatabase();
        Cursor mCursor = db.query(true, POSITION_TABLE_NAME,
                new String[]{PositionsContract.ItemEntry.project_id,
                        PositionsContract.ItemEntry.position_id,
                        PositionsContract.ItemEntry.position_name},
                PositionsContract.ItemEntry.project_id + "=" + projectId + " or " + PositionsContract.ItemEntry.project_id + "=0",
                null, null, null, null, null);
        if (mCursor != null) {
            while (mCursor.moveToNext()) {
                PositionResponseDetails positionResponseDetails = new PositionResponseDetails();
                positionResponseDetails.setPosition_id(
                        mCursor.getString(mCursor.getColumnIndex(PositionsContract.ItemEntry.position_id)));
                positionResponseDetails.setPosition_name(
                        mCursor.getString(mCursor.getColumnIndex(PositionsContract.ItemEntry.position_name)));
                positionResponseDetails.setProject_id(
                        mCursor.getString(mCursor.getColumnIndex(PositionsContract.ItemEntry.project_id)));

                positions.add(positionResponseDetails);
            }
        }

        return positions;
    }
    public void addJob(Job job) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            values.put(JobContract.ItemEntry.JOB_ID, job.getJob_id());
            values.put(JobContract.ItemEntry.JOB_NAME, job.getJob_name());
            values.put(JobContract.ItemEntry.COUNT, job.getCount());
            values.put(JobContract.ItemEntry.NOTE, job.getNote());
            values.put(JobContract.ItemEntry.OFFICE_ID, job.getOffice_id());
            values.put(JobContract.ItemEntry.PROJECT_ID, job.getProject_id());
            values.put(JobContract.ItemEntry.USER_ID, job.getUser_id());
            db.insert(JOB_TABLE_NAME, null, values);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
    public boolean sendBillboard(Job job) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(JOB_TABLE_NAME, JOB_ID + " = " + job.getJob_id() + " and " +
                PROJECT_ID + " = " + job.getProject_id() + " and " + OFFICE_ID + " = " + job.getOffice_id()
                + " and " + USER_ID + " = " + job.getUser_id(), null) > 0;
    }
    public boolean getACertainJob(String jobID, String officeID , String projectId ,String userId) {
        final SQLiteDatabase db = this.getReadableDatabase();
        Cursor retCursor;
        retCursor = db.query(JOB_TABLE_NAME,
                null,
                JobContract.ItemEntry.JOB_ID + " = " + jobID + " and "+JobContract.ItemEntry.OFFICE_ID + " = " + officeID+ " and "+JobContract.ItemEntry.PROJECT_ID + " = " + projectId+ " and "+JobContract.ItemEntry.USER_ID + " = " + userId ,
                null,
                null,
                null,
                null);

        if (retCursor.getCount() > 0) {

            return true;
        } else {

            return false;
        }
    }

*/
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    // By amr rabie add shop data
    public long addShopData(ShopModel shop) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            //values.put(ShopsContract.ItemEntry.shop_id, shop.getId());

            values.put(ShopsContract.ItemEntry.owner_name, shop.getOwner_name());
            values.put(ShopsContract.ItemEntry.type, shop.getType());
            values.put(ShopsContract.ItemEntry.shop_activity_id, shop.getShop_activity_id());
            values.put(ShopsContract.ItemEntry.width, shop.getWidth());
            values.put(ShopsContract.ItemEntry.length, shop.getLength());
            values.put(ShopsContract.ItemEntry.employee_number, shop.getEmployee_number());

            values.put(ShopsContract.ItemEntry.floor_number, shop.getFloor_number());
            values.put(ShopsContract.ItemEntry.area, shop.getArea());
            values.put(ShopsContract.ItemEntry.street, shop.getStreet());
            values.put(ShopsContract.ItemEntry.locality, shop.getLocality());
            values.put(ShopsContract.ItemEntry.alley, shop.getAlley());
            values.put(ShopsContract.ItemEntry.locality_number, shop.getLocality_number());

            values.put(ShopsContract.ItemEntry.license_number, shop.getLicense_number());
            values.put(ShopsContract.ItemEntry.license_date, shop.getLicense_date());
            values.put(ShopsContract.ItemEntry.license_end_date, shop.getLicense_end_date());
            values.put(ShopsContract.ItemEntry.license_type, shop.getLicense_type());
            values.put(ShopsContract.ItemEntry.billboard_name, shop.getBillboard_name());
            values.put(ShopsContract.ItemEntry.billboard_type, shop.getBillboard_type());

            values.put(ShopsContract.ItemEntry.billboard_width, shop.getBillboard_width());
            values.put(ShopsContract.ItemEntry.billboard_length, shop.getBillboard_length());
            values.put(ShopsContract.ItemEntry.billboard_height, shop.getBillboard_height());
            values.put(ShopsContract.ItemEntry.billboard_font_type, shop.getBillboard_font_type());



            db.insert(Shop_TABLE_NAME, null, values);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return 0;
    }

    //By Amr rabie get shopdata
    public ArrayList<ShopModel2> getShopData(String shop_id ) {
        ArrayList<ShopModel2> shops = new ArrayList<>();
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(Shop_TABLE_NAME,
                null,
                null ,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                ShopModel2 shop = new ShopModel2();
                shop.setId(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry._ID)));
                shop.setOwner_name(retCursor.getString(retCursor.getColumnIndex(owner_name)));
                shop.setType(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.type)));
                shop.setShop_activity_id(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.shop_activity_id)));
                shop.setWidth(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.width)));
                shop.setLength(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.length)));
                shop.setEmployee_number(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.employee_number)));
                shop.setFloor_number(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.floor_number)));
                shop.setArea(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.area)));
                shop.setStreet(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.street)));
                shop.setLocality(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.locality)));
                shop.setAlley(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.alley)));
                shop.setLocality_number(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.locality_number)));
                shop.setLicense_number(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.license_number)));
                shop.setLicense_date(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.license_date)));
                shop.setLicense_end_date(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.license_end_date)));
                shop.setLicense_type(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.license_type)));
                shop.setBillboard_name(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.billboard_name)));
                shop.setBillboard_type(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.billboard_type)));

                shop.setBillboard_width(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.billboard_width)));
                shop.setBillboard_length(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.billboard_length)));
                shop.setBillboard_height(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.billboard_height)));
                shop.setBillboard_font_type(retCursor.getString(retCursor.getColumnIndex(ShopsContract.ItemEntry.billboard_font_type)));


                shops.add(shop);
            }
        }

        return shops;
    }

    // By amr rabie delete shopdata
    public boolean deleteShopData(ShopModel shopModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        //return db.delete(Shop_TABLE_NAME, shop_id + " = " + shopModel.getId() , null) > 0;
        return db.delete(Shop_TABLE_NAME, null , null) > 0;
    }

    // By amr rabie add bill board
    public void addBillBoard(BillboardModel billboard) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();

            values.put(BillBoardContract.ItemEntry.OWNER_NAME, billboard.getOwner_name());
            values.put(BillBoardContract.ItemEntry.BILLBOARD_NAME, billboard.getBillboard_name());
            values.put(BillBoardContract.ItemEntry.BILLBOARD_TYPE, billboard.getBillboard_type());
            values.put(BillBoardContract.ItemEntry.WIDTH, billboard.getWidth());
            values.put(BillBoardContract.ItemEntry.HEIGHT, billboard.getHeight());
            values.put(BillBoardContract.ItemEntry.LENGTH, billboard.getLength());
            values.put(BillBoardContract.ItemEntry.FONT_LANGUAGE, billboard.getFont_language());
            values.put(BillBoardContract.ItemEntry.AREA, billboard.getArea());
            values.put(BillBoardContract.ItemEntry.LOCALITY, billboard.getLocality());
            values.put(BillBoardContract.ItemEntry.AILLEY, billboard.getAilley());
            values.put(BillBoardContract.ItemEntry.STREET, billboard.getStreet());
            values.put(BillBoardContract.ItemEntry.BULDING_NUMBER, billboard.getBulding_number());
            values.put(BillBoardContract.ItemEntry.BILLBOARD_LICENSE, billboard.getBillboard_license());
            values.put(BillBoardContract.ItemEntry.BILLBOARD_LICENSE_NUMBER, billboard.getBillboard_license_number());
            values.put(BillBoardContract.ItemEntry.LICENSE_DATE, billboard.getLicense_date());
            values.put(BillBoardContract.ItemEntry.LICENSE_END_DATE, billboard.getLicense_end_date());


            db.insert(BILL_BOARD_TABLE_NAME, null, values);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    //By Amr rabie get shopdata
    public ArrayList<BillboardModel2> getBillboards( ) {
        ArrayList<BillboardModel2> billboards = new ArrayList<>();
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(BILL_BOARD_TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                BillboardModel2 billboard = new BillboardModel2("","","","","","","","","",
                        "","","","","","","","");
                billboard.setId(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry._ID)));
                billboard.setOwner_name(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.OWNER_NAME)));
                billboard.setBillboard_name(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.BILLBOARD_NAME)));
                billboard.setBillboard_type(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.BILLBOARD_TYPE)));
                billboard.setWidth(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.WIDTH)));
                billboard.setHeight(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.HEIGHT)));
                billboard.setLength(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.LENGTH)));
                billboard.setFont_language(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.FONT_LANGUAGE)));
                billboard.setArea(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.AREA)));
                billboard.setLocality(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.LOCALITY)));
                billboard.setAilley(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.AILLEY)));
                billboard.setStreet(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.STREET)));
                billboard.setBulding_number(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.BULDING_NUMBER)));
                billboard.setBillboard_license(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.BILLBOARD_LICENSE)));
                billboard.setBillboard_license_number(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.BILLBOARD_LICENSE_NUMBER)));
                billboard.setLicense_date(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.LICENSE_DATE)));
                billboard.setLicense_end_date(retCursor.getString(retCursor.getColumnIndex(BillBoardContract.ItemEntry.LICENSE_END_DATE)));

                billboards.add(billboard);
            }
        }

        return billboards;
    }

    // By amr rabie add bill board
    public void addViolation(ViolationModel violation) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
           // values.put(ViolationContract.ItemEntry.VIOLATIONs_ID, violation.getId());

            values.put(ViolationContract.ItemEntry.SHOP_ID, violation.getShop_id());
            values.put(ViolationContract.ItemEntry.CATEGORY_ID, violation.getCategory_id());
            values.put(ViolationContract.ItemEntry.VIOLATION_ID, violation.getViolation_id());
            values.put(ViolationContract.ItemEntry.ACTION_ID, violation.getAction_id());
            values.put(ViolationContract.ItemEntry.NOTE, violation.getNote());





            db.insert(VIOLATION_TABLE_TABLE, null, values);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    //By Amr rabie get shopdata
    public ArrayList<ViolationModel> getViolation(String violation_id ) {
        ArrayList<ViolationModel> violations = new ArrayList<>();
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(VIOLATION_TABLE_TABLE,
                null,
                VIOLATIONs_ID + "=" + violation_id ,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                ViolationModel violation = new ViolationModel();
                // governor.setId(retCursor.getInt(retCursor.getColumnIndex(ItemContract.ItemEntry._ID)));
                //shop.setOwner_name(retCursor.getString(retCursor.getColumnIndex(owner_name)));
                violation.setShop_id(retCursor.getString(retCursor.getColumnIndex(ViolationContract.ItemEntry.SHOP_ID)));
                violation.setCategory_id(retCursor.getString(retCursor.getColumnIndex(ViolationContract.ItemEntry.CATEGORY_ID)));
                violation.setViolation_id(retCursor.getString(retCursor.getColumnIndex(ViolationContract.ItemEntry.VIOLATION_ID)));
                violation.setAction_id(retCursor.getString(retCursor.getColumnIndex(ViolationContract.ItemEntry.ACTION_ID)));
                violation.setNote(retCursor.getString(retCursor.getColumnIndex(ViolationContract.ItemEntry.NOTE)));


                violations.add(violation);
            }
        }

        return violations;
    }


//
//    // By amr rabie delete shopdata
//    public boolean deleteViolation(ViolationModel violationModel) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        return db.delete(VIOLATION_TABLE_TABLE, VIOLATIONs_ID + " = " + violationModel.getId() , null) > 0;
//    }


    public void addShopsActivities(ShopsActivitiesDetailsResponse shopactivity) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            // values.put(ViolationContract.ItemEntry.VIOLATIONs_ID, violation.getId());

            values.put(ShopsActivitiesContract.ItemEntry.id, shopactivity.getId());
            values.put(ShopsActivitiesContract.ItemEntry.name, shopactivity.getName());
            values.put(ShopsActivitiesContract.ItemEntry.code, shopactivity.getCode());


            db.insert(Shop_Activities_TABLE_NAME, null, values);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    //By Amr rabie get shopdata
    public ArrayList<ShopsActivitiesDetailsResponse> getShopsActivities( ) {
        String columns []={ShopsActivitiesContract.ItemEntry.id,ShopsActivitiesContract.ItemEntry.name ,ShopsActivitiesContract.ItemEntry.code};
        ArrayList<ShopsActivitiesDetailsResponse> shopsactivities = new ArrayList<>();
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(Shop_Activities_TABLE_NAME,
                columns,
                null ,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                ShopsActivitiesDetailsResponse shopsactivitie = new ShopsActivitiesDetailsResponse();
                // governor.setId(retCursor.getInt(retCursor.getColumnIndex(ItemContract.ItemEntry._ID)));
                //shop.setOwner_name(retCursor.getString(retCursor.getColumnIndex(owner_name)));
                shopsactivitie.setId(retCursor.getString(retCursor.getColumnIndex(ShopsActivitiesContract.ItemEntry.id)));
                shopsactivitie.setName(retCursor.getString(retCursor.getColumnIndex(ShopsActivitiesContract.ItemEntry.name)));
                shopsactivitie.setCode(retCursor.getString(retCursor.getColumnIndex(ShopsActivitiesContract.ItemEntry.code)));

                shopsactivities.add(shopsactivitie);
            }
        }

        return shopsactivities;
    }

//    // By amr rabie delete shopdata
    public boolean deleteShopsActivities() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Shop_Activities_TABLE_NAME, null , null) > 0;
    }

    public void addCategories(Category category) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            // values.put(ViolationContract.ItemEntry.VIOLATIONs_ID, violation.getId());

            values.put(CategoriesContract.ItemEntry.id, category.getId());
            values.put(CategoriesContract.ItemEntry.name, category.getName());
            values.put(CategoriesContract.ItemEntry.code, category.getCode());


            db.insert(Categories_TABLE_NAME, null, values);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    //By Amr rabie get shopdata
    public ArrayList<Category> getCategories( ) {
        ArrayList<Category> categories = new ArrayList<>();
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(Categories_TABLE_NAME,
                null,
                null ,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                Category category = new Category();
                // governor.setId(retCursor.getInt(retCursor.getColumnIndex(ItemContract.ItemEntry._ID)));
                //shop.setOwner_name(retCursor.getString(retCursor.getColumnIndex(owner_name)));
                category.setId(retCursor.getString(retCursor.getColumnIndex(CategoriesContract.ItemEntry.id)));
                category.setName(retCursor.getString(retCursor.getColumnIndex(CategoriesContract.ItemEntry.name)));
                category.setCode(retCursor.getString(retCursor.getColumnIndex(CategoriesContract.ItemEntry.code)));

                categories.add(category);
            }
        }

        return categories;
    }



    //    // By amr rabie delete shopdata
    public boolean deleteCategories() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Categories_TABLE_NAME, null , null) > 0;
    }

    public void addAllViolences(Violation violation) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            // values.put(ViolationContract.ItemEntry.VIOLATIONs_ID, violation.getId());

            values.put(AllViolenceContract.ItemEntry.id, violation.getId());
            values.put(AllViolenceContract.ItemEntry.name, violation.getName());
            values.put(AllViolenceContract.ItemEntry.type, violation.getType());
            values.put(AllViolenceContract.ItemEntry.financial_value, violation.getFinancial_value());
            values.put(AllViolenceContract.ItemEntry.category_id, violation.getCategory_id());


            db.insert(All_Violences_TABLE_NAME, null, values);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    //By Amr rabie get shopdata
    public ArrayList<Violation> getAllViiolances() {
        ArrayList<Violation> violations = new ArrayList<>();
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor = db.query(All_Violences_TABLE_NAME,
                null,
                null ,
                null,
                null,
                null,
                null);


        if (retCursor != null) {
            while (retCursor.moveToNext()) {
                Violation violation = new Violation();
                // governor.setId(retCursor.getInt(retCursor.getColumnIndex(ItemContract.ItemEntry._ID)));
                //shop.setOwner_name(retCursor.getString(retCursor.getColumnIndex(owner_name)));
                violation.setId(retCursor.getString(retCursor.getColumnIndex(AllViolenceContract.ItemEntry.id)));
                violation.setName(retCursor.getString(retCursor.getColumnIndex(AllViolenceContract.ItemEntry.name)));
                violation.setType(retCursor.getString(retCursor.getColumnIndex(AllViolenceContract.ItemEntry.type)));
                violation.setCategory_id(retCursor.getString(retCursor.getColumnIndex(AllViolenceContract.ItemEntry.category_id)));
                violation.setFinancial_value(retCursor.getString(retCursor.getColumnIndex(AllViolenceContract.ItemEntry.financial_value)));

                violations.add(violation);
            }
        }

        return violations;
    }



    //    // By amr rabie delete shopdata
    public boolean deleteAllViolences() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(All_Violences_TABLE_NAME, null , null) > 0;
    }


    public Long add_Shop_Data(String owner_name,String type,String shop_activity_id,String width,String length,String employee_number,String floor_number,
                              String area,String street,String alley,String locality,String locality_number,String license_number,String license_type,
                              String license_date,String license_end_date,String billboard_name,String billboard_type,String billboard_width,
                              String billboard_length,String billboard_height,String billboard_font_type
    ) {
        long rowInserted ;
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();

            values.put(ShopsContract.ItemEntry.owner_name, owner_name);
            values.put(ShopsContract.ItemEntry.type, type);
            values.put(ShopsContract.ItemEntry.shop_activity_id, shop_activity_id);
            values.put(ShopsContract.ItemEntry.width, width);
            values.put(ShopsContract.ItemEntry.length, length);
            values.put(ShopsContract.ItemEntry.employee_number, employee_number);
            values.put(ShopsContract.ItemEntry.floor_number, floor_number);
            values.put(ShopsContract.ItemEntry.area, area);
            values.put(ShopsContract.ItemEntry.street, street);
            values.put(ShopsContract.ItemEntry.alley, alley);
            values.put(ShopsContract.ItemEntry.locality, locality);
            values.put(ShopsContract.ItemEntry.locality_number, locality_number);

            values.put(ShopsContract.ItemEntry.license_number, license_number);
            values.put(ShopsContract.ItemEntry.license_type, license_type);
            values.put(ShopsContract.ItemEntry.license_date, license_date);
            values.put(ShopsContract.ItemEntry.license_end_date, license_end_date);
            values.put(ShopsContract.ItemEntry.billboard_name, billboard_name);
            values.put(ShopsContract.ItemEntry.billboard_type, billboard_type);
            values.put(ShopsContract.ItemEntry.billboard_width, billboard_width);
            values.put(ShopsContract.ItemEntry.billboard_length, billboard_length);
            values.put(ShopsContract.ItemEntry.billboard_height, billboard_height);
            values.put(ShopsContract.ItemEntry.billboard_font_type, billboard_font_type);



            rowInserted  =     db.insert(Shop_TABLE_NAME, null, values);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return rowInserted ;
    }


    public List<ShopsActivitiesDetailsResponse>  getShActivities() {

        //String[] columns={ShopsActivitiesContract.ItemEntry.id , ShopsActivitiesContract.ItemEntry.name , ShopsActivitiesContract.ItemEntry.code};
        List<ShopsActivitiesDetailsResponse>  activities = new ArrayList<>();
        // Get access to underlying database (read-only for query)
        final SQLiteDatabase db = this.getReadableDatabase();

        Cursor retCursor;
        retCursor =  db.query(Shop_Activities_TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                null);


        if(retCursor!=null){
            while (retCursor.moveToNext()) {
                ShopsActivitiesDetailsResponse  activity = new ShopsActivitiesDetailsResponse();
                // governor.setId(retCursor.getInt(retCursor.getColumnIndex(ItemContract.ItemEntry._ID)));
                activity.setCode( retCursor.getString(retCursor.getColumnIndex(ShopsActivitiesContract.ItemEntry.code)));
                activity.setId( retCursor.getString(retCursor.getColumnIndex(ShopsActivitiesContract.ItemEntry.id)));
                activity.setName( retCursor.getString(retCursor.getColumnIndex(ShopsActivitiesContract.ItemEntry.name)));
                activities.add(activity);
            }
        }

        return  activities;
    }


    public boolean deleteBillboard(String billboardId)
    {
        final SQLiteDatabase db = this.getReadableDatabase();
        return   db.delete(BILL_BOARD_TABLE_NAME, BillBoardContract.ItemEntry._ID + "=" + billboardId, null) > 0;

    }


    public boolean deleteShop(String shopId)
    {
        final SQLiteDatabase db = this.getReadableDatabase();
        return   db.delete(Shop_TABLE_NAME, ShopsContract.ItemEntry._ID + "=" + shopId, null) > 0;

    }

}