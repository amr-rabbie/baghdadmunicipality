package com.unicomg.baghdadmunicipality.Views.add_shops;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.unicomg.baghdadmunicipality.baseClass.BasePresenter;
import com.unicomg.baghdadmunicipality.data.ApisClient.ApiInterface;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.ItemDbHelper;
import com.unicomg.baghdadmunicipality.data.models.shops.ShopModel;
import com.unicomg.baghdadmunicipality.data.models.shops.ShopResponse;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesDetailsResponse;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;
import com.unicomg.baghdadmunicipality.helper.Constants;
import com.unicomg.baghdadmunicipality.helper.Utilities;

import java.util.List;

import javax.inject.Inject;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class AddShopPresenter implements BasePresenter<AddShopView> {


    AddShopView mView;
    boolean isLoaded = false;

    @Inject
    ApiInterface mApiInterface;
    @Inject
    Context mContext;
    @Inject
    ItemDbHelper mItemDbHelper;
    public AddShopPresenter(Context context){
        ((DaggerApplication)context).getAppComponent().inject(this);
    }

    public void loadItems() {
        if(!Utilities.checkConnection(mContext)){
            checkConnection(false);
            return;
        }
        mView.showLoading();
    }

    void saveShopDataOnline2(ShopModel shopModel) {
        String accesstoken= "Bearer " + Constants.getuserToken(mContext);
        mApiInterface.addShopData2(accesstoken,shopModel
        )
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ShopResponse>() {
                    @Override
                    public final void onCompleted() {

                    }

                    @Override
                    public final void onError(Throwable e) {

                        Log.e("add_shop_data",e.getMessage().toString());
                    }

                    @Override
                    public final void onNext(ShopResponse response) {

                        Log.e("Add Shop response" , response.toString());
                        Toast.makeText(mContext, response.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });
    }



    @Override
    public void onAttach(AddShopView view) {
        mView = view;
        mView.onAttache();
    }

    @Override
    public void onDetach() {
        mView = null;
    }

    public void saveShopDataoffline(String owner_name,String type,String shop_activity_id,String width,String length,String employee_number,String floor_number,
                                    String area,String street,String alley,String locality,String locality_number,String license_number,String license_type,
                                    String license_date,String license_end_date,String billboard_name,String billboard_type,String billboard_width,
                                    String billboard_length,String billboard_height,String billboard_font_type)
    {
        long rowInserted =   mItemDbHelper.add_Shop_Data(owner_name,type,shop_activity_id,width,length,employee_number,floor_number,
                area,street,alley,locality,locality_number,license_number,license_type,
                license_date,license_end_date,billboard_name,billboard_type,billboard_width,
                billboard_length,billboard_height,billboard_font_type);


        if(rowInserted > 0){
            Toast.makeText(mContext,"تم حفظ بيانات المحل",Toast.LENGTH_LONG).show();
        }



    }


    public List<ShopsActivitiesDetailsResponse> getShopactivitiesoffline(){

        return mItemDbHelper.getShActivities();
    }


    void checkConnection(boolean isConnected) {
        //check internet and  data not loaded
        if (isConnected && !isLoaded) {
            loadItems();
            isLoaded = false;
            //   mView.showMessage(mContext.getString(R.string.connect_to_internet),Color.GREEN);
        }
        if (!isConnected && isLoaded) {
            //offline check and  data loaded
            //  mView.showMessage(mContext.getString(R.string.offline),Color.WHITE);

        } else if (!isConnected && !isLoaded) {
            //get offline  data using realm
            //mView.showMessage(mContext.getString(R.string.get_data_from_local),Color.WHITE);
        } else if (isConnected && isLoaded) {
            //mView.showMessage(mContext.getString(R.string.connect_to_internet),Color.GREEN);
        }
    }

}
