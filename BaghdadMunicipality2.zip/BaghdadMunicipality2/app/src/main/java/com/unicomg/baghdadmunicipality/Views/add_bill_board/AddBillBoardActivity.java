package com.unicomg.baghdadmunicipality.Views.add_bill_board;

import android.app.DatePickerDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.unicomg.baghdadmunicipality.R;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardModel;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;
import com.unicomg.baghdadmunicipality.helper.ConnectivityReceiver;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AddBillBoardActivity extends AppCompatActivity  implements AddBillView, ConnectivityReceiver.ConnectivityReceiverListener {

    @Inject
    AddBillPresenter mainPresenter;
    @BindView(R.id.bill_owner_name)
    EditText bill_owner_name;
    @BindView(R.id.bill_name)
    EditText bill_name;
    @BindView(R.id.bill_type)
    EditText bill_type;
    @BindView(R.id.bill_length)
    EditText bill_length;
    @BindView(R.id.bill_width)
    EditText bill_width;
    @BindView(R.id.bill_height)
    EditText bill_height;
    @BindView(R.id.bill_font_type)
    Spinner bill_font_type;
    @BindView(R.id.bill_area)
    EditText bill_area;
    @BindView(R.id.bill_street)
    EditText bill_street;
    @BindView(R.id.bill_locality)
    EditText bill_locality;
    @BindView(R.id.bill_alley)
    EditText bill_alley;
    @BindView(R.id.bill_building_number)
    EditText bill_building_number;
    @BindView(R.id.bill_license)
    EditText bill_license;
    @BindView(R.id.bill_license_number)
    EditText bill_license_number;
    @BindView(R.id.bill_begin_date)
    LinearLayout bill_begin_date;
    @BindView(R.id.bill_end_date)
    LinearLayout bill_end_date;
    @BindView(R.id.txt_license_start_date)
    TextView txt_license_start_date;
    @BindView(R.id.txt_license_end_date)
    TextView txt_license_end_date;
    @BindView(R.id.btn_save)
    Button btn_save;
    @BindView(R.id.btn_back)
    ImageButton btn_back;
    @BindView(R.id.loading_indicator)
    ProgressBar loading_indicator;
    DatePickerDialog datePickerDialog;
    Calendar cal;
    String fonttype;
    private String fonttypes[] = {"اختر نوع الخط", "عربى", "انجليزى"};
    int startYear = 0;
    int startMonth = 0;
    int startDay = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bill_board);
        ButterKnife.bind(this);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savedata();
            }
        });

        bill_begin_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                final int day = c.get(Calendar.DAY_OF_MONTH);
                final Date cc = Calendar.getInstance().getTime();
                datePickerDialog = new DatePickerDialog(AddBillBoardActivity.this, new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                        if (compareDate(view.getYear() + "-" + (view.getMonth() + 1) + "-" + view.getDayOfMonth(), cc.getYear() + "-" + (cc.getMonth() + 1) + "-" + cc.getDay()) == 0
                                && compareDate(view.getYear() + "-" + (view.getMonth() + 1) + "-" + view.getDayOfMonth(), cc.getYear() + "-" + (cc.getMonth() + 1) + "-" + cc.getDay()) < 0) {
                            showMessage("تاريخ الاصدار يجب ان يكون اقل من تاريخ اليوم .");

                        } else {
                            String date = view.getYear() + "-" + (view.getMonth() + 1) + "-" + view.getDayOfMonth();
                            txt_license_start_date.setText(date);
                            startYear = year;
                            startMonth = month;
                            startDay = day;
                        }


                    }
                }, year, month, day);
                datePickerDialog.show();
            }
        });

        bill_end_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                datePickerDialog = new DatePickerDialog(AddBillBoardActivity.this, new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                        if (compareDate(view.getYear() + "-" + (view.getMonth() + 1) + "-" + view.getDayOfMonth(), startYear + "-" + (startMonth + 1) + "-" + startDay) == 0
                                && compareDate(view.getYear() + "-" + (view.getMonth() + 1) + "-" + view.getDayOfMonth(), startYear + "-" + (startMonth + 1) + "-" + startDay) < 0) {
                            showMessage("تاريخ الانتهاء يجب ان يكون اكبر من تاريخ اليوم و الاصدار");
                        } else {
                            String date = view.getYear() + "-" + (view.getMonth() + 1) + "-" + view.getDayOfMonth();
                            txt_license_end_date.setText(date);
                        }

                    }
                }, year, month, day);
                datePickerDialog.show();
            }
        });

        initFontTypeSpinner();
        ((DaggerApplication) getApplication()).getAppComponent().inject(AddBillBoardActivity.this);
         mainPresenter.onAttach(this);

    }

    public boolean validateDate(int year, int month, int day) {
        boolean asd = true;
        Date c = Calendar.getInstance().getTime();
        if (year < c.getYear()) {
            asd = false;
        } else {
            if (month + 1 < c.getMonth() + 1) {
                asd = false;
            } else {
                if (day < c.getDay()) {
                    asd = false;
                } else {
                    asd = true;
                }
            }
        }
        return asd;
    }

    private boolean validateDate2(int year, int month, int day) {
        boolean asd = true;

        if (year < startYear) {
            asd = false;
        } else {
            if (month + 1 < startMonth + 1) {
                asd = false;
            } else {
                if (day < startDay) {
                    asd = false;
                } else {
                    asd = true;
                }
            }
        }
        return asd;
    }

    public boolean validateDate3(int year, int month, int day) {
        boolean asd = true;
        Date c = Calendar.getInstance().getTime();
        if (year > c.getYear()) {
            asd = false;
        } else {
            if (month + 1 >= c.getMonth() + 1) {
                asd = false;
            } else {
                if (day >= c.getDay()) {
                    asd = false;
                } else {
                    asd = true;
                }
            }
        }
        return asd;
    }

    private int compareDate(String d1, String d2) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); //For declaring values in new date objects. use same date format when creating dates
        try {
            Date date1 = sdf.parse(d1);
            Date date2 = sdf.parse(d2);
            return date1.compareTo(date2); // = 0 ,  < -1 ,  > 1
        } catch (ParseException e) {
            e.printStackTrace();
        } finally {
            return 0;
        }
    }




    @Override
    public void onAttache() {

    }

    @Override
    public void onDetach() {

    }


    @Override
    public void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showLoading() {
        loading_indicator.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        loading_indicator.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {

    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    public boolean validate() {

        boolean valid = true;
        String ownerName = bill_owner_name.getText().toString().trim();
        String billName = bill_name.getText().toString().trim();
        String billType = bill_type.getText().toString().trim();
        String billWidth = bill_width.getText().toString().trim();
        String billLength = bill_length.getText().toString().trim();
        String billHeight = bill_height.getText().toString().trim();
        String area = bill_area.getText().toString().trim();
        String street = bill_street.getText().toString().trim();
        String locality = bill_locality.getText().toString().trim();
        String alley = bill_alley.getText().toString().trim();
        String buildingnumber = bill_building_number.getText().toString().trim();
        String lincise = bill_license.getText().toString().trim();
        String lisinceNumber = bill_license_number.getText().toString().trim();
        String startDate = txt_license_start_date.getText().toString().trim();
        String endDate = txt_license_end_date.getText().toString().trim();


        if (ownerName.isEmpty() || ownerName.length() > 255) {
            bill_owner_name.setError("خطأ في اسم المالك !");
        } else {
            bill_owner_name.setError(null);
        }

        if (billName.isEmpty() || billName.length() > 255) {
            bill_name.setError("خطأ في اسم اللوحة !");
            valid = false;
        } else {
            bill_name.setError(null);
        }


        if (billType.isEmpty() || billType.length() > 255) {
            bill_type.setError("خطأ في نوع اللوحة !");
            valid = false;
        } else {
            bill_type.setError(null);
        }


        if (billWidth.isEmpty() || Double.parseDouble(billWidth) > 99999999.99) {
            bill_width.setError("خطأ في عرض اللوحة !");
            valid = false;
        } else {
            bill_width.setError(null);
        }


        if (billLength.isEmpty() || Double.parseDouble(billLength) > 99999999.99) {
            bill_length.setError("خطأ في طول اللوحة !");
            valid = false;
        } else {
            bill_length.setError(null);
        }


        if (billHeight.isEmpty() || Double.parseDouble(billHeight) > 99999999.99) {
            bill_height.setError("خطأ في ارتفاع اللوحة !");
            valid = false;
        } else {
            bill_height.setError(null);
        }


        if (fonttype.equals("0") || fonttype.equals("-1")) {
            Toast.makeText(this, "يجب اختيار نوع اللغه .", Toast.LENGTH_SHORT).show();
            valid = false;
        } else {
            //  bill_font_type.setError(null);
        }


        if (area.isEmpty() || area.length() > 255) {
            bill_area.setError("خطأ في اسم المنطقة !");
            valid = false;
        } else {
            bill_area.setError(null);
        }


        if (locality.isEmpty() || locality.length() > 255) {
            bill_locality.setError("خطا في اسم المحلة !");
            valid = false;
        } else {
            bill_locality.setError(null);
        }


        if (alley.isEmpty() || alley.length() > 255) {
            bill_alley.setError("خطأ في اسم الزقاق !");
            valid = false;
        } else {
            bill_alley.setError(null);
        }


        if (street.isEmpty() || street.length() > 255) {
            bill_street.setError("خطأ في اسم الشارع !");
            valid = false;
        } else {
            bill_street.setError(null);
        }


        if (buildingnumber.isEmpty() || Integer.parseInt(buildingnumber) > 99999 || Integer.parseInt(buildingnumber) < 0) {
            bill_building_number.setError("خطأ في رقم المبني !");
            valid = false;
        } else {
            bill_building_number.setError(null);
        }


        if (lincise.isEmpty() || Integer.parseInt(lincise) > 99999 || Integer.parseInt(lincise) < 0) {
            bill_license.setError("خطأ في الرخصة !");
            valid = false;
        } else {
            bill_license.setError(null);
        }


        if (lisinceNumber.isEmpty() || Integer.parseInt(lisinceNumber) > 99999 || Integer.parseInt(lisinceNumber) < 0) {
            bill_license_number.setError("خطأ في رقم الرخصة !");
            valid = false;
        } else {
            bill_license_number.setError(null);
        }


        if (startDate.isEmpty() || startDate.equals("تاريخ الاصدار")) {
            txt_license_start_date.setError("يجب ادخال تاريخ الاصدار. ");
            valid = false;
        } else {
            txt_license_start_date.setError(null);
        }


        if (endDate.isEmpty() || startDate.equals("تاريخ الانتهاء")) {
            txt_license_end_date.setError("يجب ادخال تاريخ الانتهاء. ");
            valid = false;
        } else {
            txt_license_end_date.setError(null);
        }


        return valid;
    }


    public void savedata() {
        if (!validate()) {
            ///// onLoginFailed();
            return;
        }
        String ownerName = bill_owner_name.getText().toString().trim();
        String billName = bill_name.getText().toString().trim();
        String billType = bill_type.getText().toString().trim();
        String billWidth = bill_width.getText().toString().trim();
        String billLength = bill_length.getText().toString().trim();
        String billHeight = bill_height.getText().toString().trim();

        String area = bill_area.getText().toString().trim();
        String street = bill_street.getText().toString().trim();
        String locality = bill_locality.getText().toString().trim();
        String alley = bill_alley.getText().toString().trim();
        String buildingnumber = bill_building_number.getText().toString().trim();
        String lincise = bill_license.getText().toString().trim();
        String lisinceNumber = bill_license_number.getText().toString().trim();
        String startDate = txt_license_start_date.getText().toString().trim();
        String endDate = txt_license_end_date.getText().toString().trim();

        BillboardModel billboardModel = new BillboardModel(
                ownerName,
                billName,
                billType,
                billWidth,
                billLength,
                billHeight,
                fonttype,
                area,
                locality,
                alley,
                street,
                buildingnumber,
                lincise,
                lisinceNumber,
                startDate,
                endDate
        );

        ConnectivityManager cm =
                (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (activeNetwork != null && activeNetwork.isConnectedOrConnecting()) {
            mainPresenter.saveToServer(billboardModel);

        } else {
            mainPresenter.saveLocally(billboardModel);
        }
    }

    private void initFontTypeSpinner() {

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, fonttypes);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout
                .simple_spinner_dropdown_item);
        bill_font_type.setAdapter(spinnerArrayAdapter);

        bill_font_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                fonttype = (String) parent.getItemAtPosition(position);

                if (fonttype.equals("عربى")) {
                    fonttype = "1";
                } else if (fonttype.equals("انجليزى")) {
                    fonttype = "2";
                } else {
                    fonttype = "0";
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                fonttype = "-1";
            }
        });

    }
}
