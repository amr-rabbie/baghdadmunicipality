package com.unicomg.baghdadmunicipality.data.ApisClient;
import com.unicomg.baghdadmunicipality.data.models.Login.AccessTokenModel;
import com.unicomg.baghdadmunicipality.data.models.Login.Login;
import com.unicomg.baghdadmunicipality.data.models.Login.LoginModel;
import com.unicomg.baghdadmunicipality.data.models.category.CategoriesResponse;

import com.unicomg.baghdadmunicipality.data.models.shops.ShopModel;
import com.unicomg.baghdadmunicipality.data.models.shops.ShopResponse;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesDetailsResponse;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardModel;
import com.unicomg.baghdadmunicipality.data.models.billboard.BillboardResponse;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesResponse;
import com.unicomg.baghdadmunicipality.data.models.category.CategoriesResponse;
import com.unicomg.baghdadmunicipality.data.models.violation.VilationImageResponse;
import com.unicomg.baghdadmunicipality.data.models.violation.ViolationImage;
import com.unicomg.baghdadmunicipality.data.models.violation.ViolationModel;
import com.unicomg.baghdadmunicipality.data.models.violation.ViolationResponse;

import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;
import rx.Observable;

public interface ApiInterface {
    @FormUrlEncoded
    @POST(EndPoints.LOGIN)
    Observable<AccessTokenModel> getLogin(
            @Field("email") String email,
            @Field("password") String pw
    );


    @GET(EndPoints.GET_LOGin_Data)
    Observable<LoginModel> getLoginData(
            @Header("Authorization") String access_token


    );

    @GET(EndPoints.GET_Shops_ctivities)
    Observable<ShopsActivitiesResponse> getShopsActivities(
            @Header("Authorization") String access_token

    );


    // By Elamary
    //////////////////////////////////
    @GET(EndPoints.ALL_CATEGORIES)
    Observable<CategoriesResponse> getCategories(@Header("Authorization")   String token);
    @GET(EndPoints.ALL_VIOLATIONS)
    Observable<ViolationResponse> getViolation(@Header("authorization") String token , @Path("categoryId")  String catId );
    @POST(EndPoints.ADD_BILLBORAD)
    Observable<BillboardResponse> saveBillboard(@Header("Authorization") String token  , @Body BillboardModel billboardModel);
    @POST(EndPoints.ADD_VILATION_MONITORING)
    Observable<ViolationResponse> saveViolation(@Header("authorization") String token  , @Body ViolationModel violationModel);
    @POST(EndPoints.ADD_IMAGE)
    Observable<VilationImageResponse> saveViolation(@Header("authorization") String token  , @Body ViolationImage violationModel);
    /////////////////////////////////



    @POST(EndPoints.Post_Add_Shop_Data)
    Observable<ShopResponse> addShopData2(@Header("authorization") String token  , @Body ShopModel shopModel);

}
