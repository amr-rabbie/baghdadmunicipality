package com.unicomg.baghdadmunicipality.Views.add_shops;

import android.app.DatePickerDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.unicomg.baghdadmunicipality.R;
import com.unicomg.baghdadmunicipality.Views.bill_board_list.BillListFragment;
import com.unicomg.baghdadmunicipality.Views.shopslist.ShopsListFragment;
import com.unicomg.baghdadmunicipality.adapters.ShopActivitiesSpinnerAdapter;
import com.unicomg.baghdadmunicipality.data.models.shops.ShopModel;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesDetailsResponse;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;


public class AddShopFragment extends Fragment implements AdapterView.OnItemSelectedListener, NavigationView.OnNavigationItemSelectedListener   , AddShopView {

    @Inject
    AddShopPresenter addShopPresenter;
    private View mView;
    TextView edt_license_date,edt_license_end_date;
    private EditText edt_owner_name,edt_area,edt_street,edt_locality,edt_width,edt_length,edt_alley,edt_employee_number,edt_shop_number,edt_floor_number;
    private EditText edt_locality_license_number,edt_license_type,edt_billboard_name,edt_billboard_type,edt_billboard_width,edt_billboard_length,edt_billboard_height;
    private Spinner sp_type,sp_shop_activities_id,sp_billboard_font_type;
    private Button btn_previous,btn_next;
    private List<ShopsActivitiesDetailsResponse> shopsactivityoffline;
    private String shopactivityid;
    private String shopactivityname,shopactivitycode;

    private String  types [] ={"اخنر نوع المحل","ملك","ايجار"};
    private String fonttypes [] ={"اختر نوع الخط","عربى","انجليزى"};
    private String fonttype,type;
    final Calendar myCalendar = Calendar.getInstance();
    final Calendar myCalendar2 = Calendar.getInstance();

    String owner_name,width,length,employee_number,floor_number,area,street,alley,locality,locality_number,billboard_height;
    String license_number,license_type,license_date,license_end_date,billboard_name,billboard_type,billboard_width,billboard_length;


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    @BindView(R.id.btn_back2)
    Button btn_back2;

    @BindView(R.id.btn_back)
    ImageButton btn_back;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_add_shop, container, false);

        ButterKnife.bind(this, v);
        ((DaggerApplication) getActivity().getApplication()).getAppComponent().inject(this);
        getActivity().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        initctrls(v);
        initshopactivitiesspinner();
        inittypespinner();
        initfonttypespinner();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };

        edt_license_date.setOnClickListener(new View.OnClickListener() {

            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getActivity(), date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        final DatePickerDialog.OnDateSetListener date2 = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar2.set(Calendar.YEAR, year);
                myCalendar2.set(Calendar.MONTH, monthOfYear);
                myCalendar2.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel2();
            }

        };

        edt_license_end_date.setOnClickListener(new View.OnClickListener() {

            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getActivity(), date2, myCalendar2
                        .get(Calendar.YEAR), myCalendar2.get(Calendar.MONTH),
                        myCalendar2.get(Calendar.DAY_OF_MONTH)).show();
            }
        });



        btn_next.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                saveShopData();
            }
        });

        btn_back2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShopsListFragment fragment = ShopsListFragment.newInstance("", "");
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction =
                        fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameLayout_container, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });


        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShopsListFragment fragment = ShopsListFragment.newInstance("", "");
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction =
                        fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frameLayout_container, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });


        return v;
    }


    private void updateLabel() {
        //String myFormat = "MM/dd/yy"; //In which you need put here
        String myFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        edt_license_date.setText(sdf.format(myCalendar.getTime()));
    }

    private void updateLabel2() {
        //String myFormat = "MM/dd/yy"; //In which you need put here
        String myFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        edt_license_end_date.setText(sdf.format(myCalendar2.getTime()));
    }

    private void initfonttypespinner() {
        Spinner spinner = new Spinner(getActivity());
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>
                (getActivity(), android.R.layout.simple_spinner_item,
                        fonttypes); //selected item will look like a spinner set from XML
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout
                .simple_spinner_dropdown_item);
        sp_billboard_font_type.setAdapter(spinnerArrayAdapter);

        sp_billboard_font_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                fonttype = (String) parent.getItemAtPosition(position);

                if(fonttype.equals("عربى")){
                    fonttype="1";
                }else{
                    fonttype="2";
                }

                Log.e("fonttype_error", fonttype);



            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getActivity(), "من فضلك اختر نوع الخط", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void inittypespinner() {
        Spinner spinner = new Spinner(getActivity());
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>
                (getActivity(), android.R.layout.simple_spinner_item,
                        types); //selected item will look like a spinner set from XML
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout
                .simple_spinner_dropdown_item);
        sp_type.setAdapter(spinnerArrayAdapter);

        sp_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                type = (String) parent.getItemAtPosition(position);

                if(type.equals("ملك")){
                    type="1";
                }else{
                    type="2";
                }


                Log.e("type_error", type);



            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getActivity(), "من فضلك اختر نوع المحل", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initshopactivitiesspinner() {


            shopsactivityoffline = addShopPresenter.getShopactivitiesoffline();


        shopsactivityoffline.add(0, new ShopsActivitiesDetailsResponse("-1", "اختر نشاط المحل", "0"));

        ShopActivitiesSpinnerAdapter govSpinnerAdapter = new ShopActivitiesSpinnerAdapter(getActivity(), R.layout.spinneritem, shopsactivityoffline);
        sp_shop_activities_id.setAdapter(govSpinnerAdapter);


        sp_shop_activities_id.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                shopactivityid = shopsactivityoffline.get(position).getId();
                shopactivitycode = shopsactivityoffline.get(position).getCode();
                shopactivityname = shopsactivityoffline.get(position).getName();
                Log.e("shopactivityid_error", shopactivityid);
                //citiesList.clear();


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getActivity(), "من فضلك اختر نشاط المحل", Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void initctrls(View v) {
        edt_owner_name=v.findViewById(R.id.edt_owner_name);
        edt_area=v.findViewById(R.id.edt_area);
        sp_type=v.findViewById(R.id.sp_type);
        edt_street=v.findViewById(R.id.edt_street);
        sp_shop_activities_id=v.findViewById(R.id.sp_shop_activities_id);
        edt_locality=v.findViewById(R.id.edt_locality);
        edt_width=v.findViewById(R.id.edt_width);
        edt_length=v.findViewById(R.id.edt_length);
        edt_alley=v.findViewById(R.id.edt_alley);
        edt_employee_number=v.findViewById(R.id.edt_employee_number);

        edt_shop_number=v.findViewById(R.id.edt_shop_number);
        edt_floor_number=v.findViewById(R.id.edt_floor_number);
        edt_locality_license_number=v.findViewById(R.id.edt_locality_license_number);
        edt_license_type=v.findViewById(R.id.edt_license_type);
        edt_license_date=v.findViewById(R.id.edt_license_date);
        edt_license_end_date=v.findViewById(R.id.edt_license_end_date);
        edt_billboard_name=v.findViewById(R.id.edt_billboard_name);

        edt_billboard_type=v.findViewById(R.id.edt_billboard_type);
        edt_billboard_width=v.findViewById(R.id.edt_billboard_width);
        edt_billboard_length=v.findViewById(R.id.edt_billboard_length);
        edt_billboard_height=v.findViewById(R.id.edt_billboard_height);
        sp_billboard_font_type=v.findViewById(R.id.sp_billboard_font_type);

        btn_previous=v.findViewById(R.id.btn_previous);
        btn_next=v.findViewById(R.id.btn_next);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    // TODO: Rename and change types and number of parameters
    public static AddShopFragment newInstance(String param1, String param2) {
        AddShopFragment fragment = new AddShopFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }

    @Override
    public void showMessage(String message, int mColor) {

    }

    @Override
    public void showMessageForSave(String message) {

    }

    @Override
    public void onAttache() {

    }



    private void saveShopData() {
        owner_name=edt_owner_name.getText().toString();
        width=edt_width.getText().toString();
        length=edt_length.getText().toString();
        employee_number=edt_employee_number.getText().toString();
        floor_number=edt_floor_number.getText().toString();
        area=edt_area.getText().toString();
        street=edt_street.getText().toString();
        alley=edt_alley.getText().toString();
        locality=edt_locality.getText().toString();
        locality_number=edt_locality_license_number.getText().toString();
        license_number=edt_locality_license_number.getText().toString();
        license_type=edt_license_type.getText().toString();
        license_date=edt_license_date.getText().toString();
        license_end_date=edt_license_end_date.getText().toString();
        billboard_name=edt_billboard_name.getText().toString();
        billboard_type=edt_billboard_type.getText().toString();
        billboard_width=edt_billboard_width.getText().toString();
        billboard_length=edt_billboard_length.getText().toString();
        billboard_height=edt_billboard_height.getText().toString();


        if (owner_name.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل اسم المالك", Toast.LENGTH_SHORT).show();
            edt_owner_name.setError("من فضلك أدخل اسم المالك");
        }else if(type.equals("اخنر نوع المحل")){
            Toast.makeText(getActivity(), "من فضلك اختار نوع المحل", Toast.LENGTH_SHORT).show();
            //sp_type.setError("من فضلك أدخل اسم المالك");
        }else if(width.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل عرض المحل", Toast.LENGTH_SHORT).show();
            edt_width.setError("من فضلك أدخل عرض المحل");
        }else if(length.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل طول المحل", Toast.LENGTH_SHORT).show();
            edt_length.setError("من فضلك أدخل طول المحل");
        }else if(employee_number.isEmpty() ){
            Toast.makeText(getActivity(), "من فضلك أدخل عدد الموظفين", Toast.LENGTH_SHORT).show();
            edt_employee_number.setError("من فضلك أدخل عدد الموظفين");
        }else if(floor_number.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل عدد الطوابق", Toast.LENGTH_SHORT).show();
            edt_floor_number.setError("من فضلك أدخل عدد الطوابق");
        }else if(area.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل المنطقة", Toast.LENGTH_SHORT).show();
            edt_area.setError("من فضلك أدخل المنطقة");
        }else if(street.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل اسم الشارع", Toast.LENGTH_SHORT).show();
            edt_street.setError("من فضلك أدخل اسم الشارع");
        }else if(alley.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل اسم المحلة", Toast.LENGTH_SHORT).show();
            edt_alley.setError("من فضلك أدخل اسم المحلة");
        }else if(locality.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل اسم الزقاق", Toast.LENGTH_SHORT).show();
            edt_locality.setError("من فضلك أدخل اسم الزقاق");
        }else if(locality_number.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل رقم العقار", Toast.LENGTH_SHORT).show();
            edt_locality.setError("من فضلك أدخل رقم العقار");
        }else if(license_number.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل رقم الرخصة", Toast.LENGTH_SHORT).show();
            edt_locality_license_number.setError("من فضلك أدخل رقم الرخصة");
        }else if(license_type.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل نوع الرخصة", Toast.LENGTH_SHORT).show();
            edt_license_type.setError("من فضلك أدخل نوع الرخصة");
        }else if(license_date.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل تاريخ بداية الرخصة", Toast.LENGTH_SHORT).show();
            edt_license_date.setError("من فضلك أدخل تاريخ بداية الرخصة");
        }else if(license_end_date.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل تاريخ نهاية الرخصة", Toast.LENGTH_SHORT).show();
            edt_license_end_date.setError("من فضلك أدخل تاريخ نهاية الرخصة");
        }else if(billboard_name.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل اسم الوحة", Toast.LENGTH_SHORT).show();
            edt_billboard_name.setError("من فضلك أدخل اسم الوحة");
        }else if(billboard_type.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل نوع الوحة", Toast.LENGTH_SHORT).show();
            edt_billboard_type.setError("من فضلك أدخل نوع الوحة");
        }else if(billboard_width.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل عرض الوحة", Toast.LENGTH_SHORT).show();
            edt_billboard_width.setError("من فضلك أدخل عرض الوحة");
        }else if(billboard_height.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل ارتفاع الوحة", Toast.LENGTH_SHORT).show();
            edt_billboard_height.setError("من فضلك أدخل ارتفاع الوحة");
        }else if(billboard_length.isEmpty()){
            Toast.makeText(getActivity(), "من فضلك أدخل طول الوحة", Toast.LENGTH_SHORT).show();
            edt_billboard_length.setError("من فضلك أدخل طول الوحة");
        }else if(fonttype.equals("اختر نوع الخط")){
            Toast.makeText(getActivity(), "من فضلك اختار نوع الخط", Toast.LENGTH_SHORT).show();
            //sp_type.setError("من فضلك أدخل اسم المالك");
        }else if(shopactivityname.equals("اختر نشاط المحل")){
            Toast.makeText(getActivity(), "من فضلك اختار نوع نشاط المحل", Toast.LENGTH_SHORT).show();
            //sp_type.setError("من فضلك أدخل اسم المالك");
        }
        else {
            ShopModel shopModel = new ShopModel(
                    owner_name,  type,  shopactivityid,
                    width,  length,  employee_number,
                    floor_number,  area,  street,  alley,
                    locality,  locality_number,  license_number,
                    license_type,  license_date,  license_end_date,
                    billboard_name,  billboard_type,  billboard_width,
                    billboard_length,  billboard_height,  fonttype
            );

            ConnectivityManager cm =
                    (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            if (activeNetwork != null && activeNetwork.isConnectedOrConnecting()) {
                addShopPresenter.saveShopDataOnline2(shopModel);

            } else {
                addShopPresenter.saveShopDataoffline(owner_name,type,shopactivityid,width,length,employee_number,floor_number,
                        area,street,alley,locality,locality_number,license_number,license_type,
                        license_date,license_end_date,billboard_name,billboard_type,billboard_width,
                        billboard_length,billboard_height,fonttype);
            }

        }

    }
}
