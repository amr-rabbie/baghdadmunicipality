package com.unicomg.baghdadmunicipality.Views.splash;

import android.content.Context;
import android.util.Log;


import com.unicomg.baghdadmunicipality.baseClass.BasePresenter;
import com.unicomg.baghdadmunicipality.data.ApisClient.ApiInterface;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.ItemDbHelper;
import com.unicomg.baghdadmunicipality.data.models.category.CategoriesResponse;
import com.unicomg.baghdadmunicipality.data.models.category.Category;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesDetailsResponse;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesResponse;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;
import com.unicomg.baghdadmunicipality.helper.Constants;
import com.unicomg.baghdadmunicipality.helper.Utilities;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class SplashPresenter implements BasePresenter<SplashView> {
    SplashView mView;

    boolean isLoaded = false;
    //inject api interface object
    @Inject
    ApiInterface mApiInterface;
    @Inject
    Context mContext;
    // create sqllit reference
    @Inject
    ItemDbHelper mItemDbHelper;
    @Override
    public void onAttach(SplashView view) {
        mView = view;
        mView.onAttache();
    }

    @Override
    public void onDetach() {
        mView = null;
    }

    //create Constructor to get reference of api interface object
    public SplashPresenter(Context context){
        ((DaggerApplication)context).getAppComponent().inject(this);
    }

    public void getShopsActivities() {

        mApiInterface.getShopsActivities("Bearer " + Constants.getuserToken(mContext))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ShopsActivitiesResponse>() {
                    @Override
                    public final void onCompleted() {

                        getAllCategories();
                    }

                    @Override
                    public final void onError(Throwable e) {
                        Log.e("shop_activities",e.getMessage().toString());
                    }

                    @Override
                    public void onNext(ShopsActivitiesResponse shopactivities) {

                        if (!mItemDbHelper.getShopsActivities().isEmpty()) {
                            mItemDbHelper.deleteShopsActivities();
                        }

                        List<ShopsActivitiesDetailsResponse> shopactivitie = shopactivities.getData();
                        for(int i=0;i<shopactivitie.size();i++) {
                            ShopsActivitiesDetailsResponse shopactivity= shopactivitie.get(i);
                            Log.e("shop_activities",shopactivity.toString());
                            mItemDbHelper.addShopsActivities(shopactivity);
                        }
                    }
                });
    }

    public void getAllCategories() {


        mApiInterface.getCategories("Bearer " +Constants.getuserToken(mContext))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<CategoriesResponse>() {
                    @Override
                    public final void onCompleted() {

                    }

                    @Override
                    public final void onError(Throwable e) {

                        Log.e("categories",e.getMessage().toString());
                    }

                    @Override
                    public void onNext(CategoriesResponse category) {

                        List<Category> categories = category.getCategories();

                        if (!mItemDbHelper.getCategories().isEmpty())
                            mItemDbHelper.deleteCategories();

                        for(int i=0;i<categories.size();i++) {
                            Category category1 = categories.get(i);
                            Log.e("category",category1.toString());
                            mItemDbHelper.addCategories(category1);
                        }
                    }
                });
    }



    void checkConnection(boolean isConnected) {
        //check internet and  data not loaded
        if(isConnected  && !isLoaded){
            //loadGovernor();
            isLoaded = false;
         //   mView.showMessage(mContext.getString(R.string.connect_to_internet),Color.GREEN);
        }

        if(!isConnected){
            new android.os.Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
               //
                    //mView.startLoginActivity();
                }
            } , 1000);

        }
        else if(!isConnected && isLoaded){
            //offline check and  data loaded
          //  mView.showMessage(mContext.getString(R.string.offline),Color.WHITE);

        }
        else if(!isConnected && !isLoaded){
            //get offline  data using realm
            //mView.showMessage(mContext.getString(R.string.get_data_from_local),Color.WHITE);
       //     mView.updateList(mItemDbHelper.getAllItems());

        }else if(isConnected && isLoaded){
            //mView.showMessage(mContext.getString(R.string.connect_to_internet),Color.GREEN);
        }
    }

}
