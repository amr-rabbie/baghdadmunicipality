package com.unicomg.baghdadmunicipality.baseClass;


// this class created to be base for each View in all application
public interface BaseView {
    void onAttache();
    void onDetach();
}
