package com.unicomg.baghdadmunicipality.Views.login;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;


import com.unicomg.baghdadmunicipality.Views.mainscreen.MainActivity;
import com.unicomg.baghdadmunicipality.baseClass.BasePresenter;
import com.unicomg.baghdadmunicipality.data.ApisClient.ApiInterface;
import com.unicomg.baghdadmunicipality.data.LocalSqlite.ItemDbHelper;
import com.unicomg.baghdadmunicipality.data.models.Login.AccessTokenModel;
import com.unicomg.baghdadmunicipality.data.models.Login.Info;
import com.unicomg.baghdadmunicipality.data.models.Login.Login;
import com.unicomg.baghdadmunicipality.data.models.Login.LoginModel;
import com.unicomg.baghdadmunicipality.data.models.category.CategoriesResponse;
import com.unicomg.baghdadmunicipality.data.models.category.Category;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesDetailsResponse;
import com.unicomg.baghdadmunicipality.data.models.shops_activities.ShopsActivitiesResponse;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;
import com.unicomg.baghdadmunicipality.helper.Constants;
import com.unicomg.baghdadmunicipality.helper.Utilities;

import java.util.List;

import javax.inject.Inject;

import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class LoginPresenter  implements BasePresenter<LoginView> {
    LoginView mView;
    boolean isLoaded = false;

    //inject api interface object
    @Inject
    ApiInterface mApiInterface;
    @Inject
    Context mContext;
    // create sqllit reference
    @Inject
    ItemDbHelper mItemDbHelper;
    private String access_token;

    @Override
    public void onAttach(LoginView view) {
        mView = view;
        mView.onAttache();
    }

    @Override
    public void onDetach() {
        mView = null;
    }

    //create Constructor to get reference of api interface object
    public LoginPresenter(Context context){
        ((DaggerApplication)context).getAppComponent().inject(this);
    }

    //this function created to load items from specific endpoint
    public void loadItems() {
        if(!Utilities.checkConnection(mContext)){
            checkConnection(false);
            return;
        }
        mView.showLoading();
    }

    void checkConnection(boolean isConnected) {
        //check internet and  data not loaded
        if(isConnected  && !isLoaded){
            loadItems();
            isLoaded = false;
            //   mView.showMessage(mContext.getString(R.string.connect_to_internet),Color.GREEN);
        }if(!isConnected && isLoaded){
            //offline check and  data loaded
            //  mView.showMessage(mContext.getString(R.string.offline),Color.WHITE);

        }else if(!isConnected && !isLoaded){
            //get offline  data using realm
            //mView.showMessage(mContext.getString(R.string.get_data_from_local),Color.WHITE);
         }else if(isConnected && isLoaded){
            //mView.showMessage(mContext.getString(R.string.connect_to_internet),Color.GREEN);
        }
    }

    public  void getLogin(final String email, final String pw , final LinearLayout ll, final Dialog dialog, final ProgressBar probar){

        if(!Utilities.checkConnection(mContext)){
            checkConnection(false);

            mView.showMessage("من فضلك قم بالاتصال بالانترنت",0);
            return;
        }
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms


                dialog.show();
       //mView.showLoading();
        mApiInterface.getLogin(email,pw)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<AccessTokenModel>() {
                    @Override
                    public final void onCompleted() {

                        //mView.hideLoading();

                        if( access_token != null && ! access_token.isEmpty()    ) {
                            getLoginData(access_token);
                        }else{
                            Toast.makeText(mContext,"اسم المستخدم او كلمة السر غير صحيحة",Toast.LENGTH_LONG).show();
                            dialog.dismiss();
                        }
                    }

                    @Override
                    public final void onError(Throwable e) {

                        probar.setVisibility(View.GONE);
                        dialog.dismiss();
                        Toast.makeText(mContext,"اسم المستخدم او كلمة السر غير صحيحة",Toast.LENGTH_LONG).show();
                        Log.e("access_token",e.getMessage().toString());
                    }

                    @Override
                    public void onNext(AccessTokenModel accessTokenModel) {

                        access_token = accessTokenModel.getAccess_token();
                        Constants.saveAcessToked(access_token ,mContext );

                    }
                });

            }
        }, 1000);


        dialog.dismiss();
    }

    public void getShopsActivities() {
        access_token=Constants.getuserToken(mContext);
        mApiInterface.getShopsActivities("Bearer " + access_token)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<ShopsActivitiesResponse>() {
                    @Override
                    public final void onCompleted() {

                        getAllCategories();
                    }

                    @Override
                    public final void onError(Throwable e) {
                        Log.e("shop_activities",e.getMessage().toString());
                    }

                    @Override
                    public void onNext(ShopsActivitiesResponse shopactivities) {

                       if (!mItemDbHelper.getShopsActivities().isEmpty()) {
                           mItemDbHelper.deleteShopsActivities();
                       }

                            List<ShopsActivitiesDetailsResponse> shopactivitie = shopactivities.getData();
                            for(int i=0;i<shopactivitie.size();i++) {
                                ShopsActivitiesDetailsResponse shopactivity= shopactivitie.get(i);
                                Log.e("shop_activities",shopactivity.toString());
                                mItemDbHelper.addShopsActivities(shopactivity);

                                //Toast.makeText(mContext,shopactivity.toString(),Toast.LENGTH_LONG).show();
                            }
                    }
                });
    }

    public void getAllCategories() {

        access_token=Constants.getuserToken(mContext);

        mApiInterface.getCategories("Bearer " +access_token)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<CategoriesResponse>() {
                    @Override
                    public final void onCompleted() {

                       mView.openProjectsActivity();

                    }

                    @Override
                    public final void onError(Throwable e) {

                        Log.e("categories",e.getMessage().toString());
                    }

                    @Override
                    public void onNext(CategoriesResponse category) {

                        List<Category> categories = category.getCategories();

                        if (!mItemDbHelper.getCategories().isEmpty())
                            mItemDbHelper.deleteCategories();

                        for(int i=0;i<categories.size();i++) {
                            Category category1 = categories.get(i);
                            Log.e("category",category1.toString());
                            mItemDbHelper.addCategories(category1);
                        }
                    }
                });
    }

    public void getLoginData(String accesstoken){

        mApiInterface.getLoginData("Bearer " +accesstoken)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<LoginModel>() {
                    @Override
                    public final void onCompleted() {

                        getShopsActivities();
                    }

                    public final void onError(Throwable e) { }

                    @Override
                    public void onNext(LoginModel loginModel) {
                        String user_id = loginModel.getId();
                        String first_name = loginModel.getFirst_name();
                        String last_name = loginModel.getLast_name();
                        String username = loginModel.getUsername();
                        String email = loginModel.getEmail();
                        String permission = loginModel.getPermission();
                        String is_active = loginModel.getIs_active();
                        Log.e("logindata",loginModel.toString());
                        Constants.saveLoginData(user_id,first_name,last_name,username,email,permission,is_active,mContext);
                        Toast.makeText(mContext,  "مرحبا بك "   + first_name + " " + last_name, Toast.LENGTH_SHORT).show();
                    }

                });

    }


}
