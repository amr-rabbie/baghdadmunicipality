package com.unicomg.baghdadmunicipality.Views.add_violation;

import com.unicomg.baghdadmunicipality.baseClass.BaseView;

public interface AddViolationView extends BaseView {

    void showMessage(String message, int mColor);
}
