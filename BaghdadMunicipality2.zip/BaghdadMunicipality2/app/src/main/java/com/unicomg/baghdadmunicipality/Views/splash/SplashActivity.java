package com.unicomg.baghdadmunicipality.Views.splash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.unicomg.baghdadmunicipality.R;
import com.unicomg.baghdadmunicipality.Views.login.LoginActivity;
import com.unicomg.baghdadmunicipality.Views.mainscreen.MainActivity;
import com.unicomg.baghdadmunicipality.di.DaggerApplication;
import com.unicomg.baghdadmunicipality.helper.ConnectivityReceiver;
import com.unicomg.baghdadmunicipality.helper.Constants;

import javax.inject.Inject;

import butterknife.ButterKnife;

public class SplashActivity extends AppCompatActivity implements SplashView, ConnectivityReceiver.ConnectivityReceiverListener {

    @Inject
    SplashPresenter mainPresenter;
    ProgressBar progressBar;
    private TextView txtVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        // progressBar = findViewById(R.id.progressBar2);
        ButterKnife.bind(this);
        ((DaggerApplication) getApplication()).getAppComponent().inject(this);
        mainPresenter.onAttach(this);
        // txtVersion = findViewById(R.id.textView_version);
        // txtVersion.setText("© Unicomg " + BuildConfig.VERSION_NAME);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                String userid = Constants.getuserId(SplashActivity.this);
                if (!userid.isEmpty()) {
                    mainPresenter.getShopsActivities();
                    Intent i = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(i);
                }
                else
                {
                    Intent mainIntent = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(mainIntent);
                }
                finish();
            }
        }, 3000);
    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {
        mainPresenter.checkConnection(isConnected);
    }


    @Override
    public void showMessage(String message, int mColor) {
    }


    @Override
    public void onAttache() {
    }

    @Override
    public void onDetach() {
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        startActivity(intent);
    }
}